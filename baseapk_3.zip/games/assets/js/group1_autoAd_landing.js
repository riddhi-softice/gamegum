// Auto Ads
(function() {
    const script = document.createElement('script');
    script.async = true;
    script.src = "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8263720079379422";
    script.crossOrigin = "anonymous";

    document.head.appendChild(script);
})();
     