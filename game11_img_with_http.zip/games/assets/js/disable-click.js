// window.onload = function () {
//     document.body.classList.add("loaded");
// };

// PAGE RIGHT CLICK DISABLE
document.addEventListener("contextmenu", function (event) {
    event.preventDefault();
	// alert("Right-click is disabled!");
});

// VIEWING SOURCE DISABLE
document.addEventListener("keydown", function (event) {
    if (event.ctrlKey && (event.key === "u" || event.key === "U")) {
        event.preventDefault();
        // alert("Viewing source is disabled!");
    }
    if (event.key === "F12" || (event.ctrlKey && event.shiftKey && (event.key === "i" || event.key === "j" || event.key === "I" || event.key === "J"))) {
        event.preventDefault();
        // alert("Inspect Element is disabled!");
    }
});